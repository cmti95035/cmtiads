# MobFox-Android-Demo
This repository contains an example app demonstrating how MobFox ads can be integrated into Android applications.

To read more about MobFox Android SDK, please also check the
[MobFox Android SDK GitHub page](https://github.com/mobfox/MobFox-Android-SDK).
There you can also find the [Wiki containing integration instructions](https://github.com/mobfox/MobFox-Android-SDK/wiki).
